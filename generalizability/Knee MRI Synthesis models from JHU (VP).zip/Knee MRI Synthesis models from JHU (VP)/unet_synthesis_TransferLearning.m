% Training Data
trainImages = '/home/vivianzhang/Desktop/Gradient/curated_dataset/train_split/sagittal/orig';

fs_images = imageDatastore(trainImages,"IncludeSubfolders",true,'FileExtensions','.dcm','ReadFcn',@(x) dicomread(x));

imagesDir = '/home/vivianzhang/Desktop/Gradient/curated_dataset/train_split/sagittal/label';
non_fs_images_dir = fullfile(imagesDir);
nonfs_images = imageDatastore(non_fs_images_dir,"IncludeSubfolders",true,'FileExtensions','.dcm','ReadFcn',@(x) dicomread(x));

im_nfs = nonfs_images.readimage(1);
im_fs = fs_images.readimage(1);
im_nfs = imresize(ConvertImgToSquare(im_nfs),[256 256]);
im_nfs = uint8(255 *mat2gray(im_nfs));
im_fs = imresize(ConvertImgToSquare(im_fs),[256 256]);
im_fs = uint8(255 *mat2gray(im_fs));

imshow(im_fs);
title('FS Image - Final Result');
figure; imshow(im_nfs);
title('Non-FS Image - Input');


XTrain = nonfs_images;
trainY = fs_images;

%augmenter = imageDataAugmenter( ...
%    'RandRotation',@()randi([0,1],1)*90, ...
%    'RandXReflection',true);

miniBatchSize = 10;
patchSize = [40 40];
patchds = randomPatchExtractionDatastore(nonfs_images,fs_images,patchSize,'PatchesPerImage',40);
patchds.MiniBatchSize = miniBatchSize;


%%

% Original training parameters

    initialLearningRate = 0.0005;
    maxEpochs = 20;
    miniBatchSize = 10;
    l2reg = 0.0001;
    validationFrequency = floor(numel(trainY)/miniBatchSize);  % size of training dataset / batch size
    

    options = trainingOptions('sgdm',...
    'InitialLearnRate', initialLearningRate, ...
    'Momentum',0.9,...
    'L2Regularization',l2reg,...
    'MaxEpochs',maxEpochs,...
    'MiniBatchSize',miniBatchSize,...
    'VerboseFrequency',20,...
    'LearnRateSchedule','piecewise',...    
    'Shuffle','every-epoch',...
    'Plots','training-progress',...
    'GradientThresholdMethod','l2norm',...
    'ExecutionEnvironment','auto',...
    'GradientThreshold',0.05);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	% load your deepnet mat file: deepnet = 'path_to_the_file'
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    deepnet = 'deepnet_unet_noNorm_98Pats_batch30_learn_05_SAG.mat';

    [deepnet,trainInfo] = trainNetwork(patchds,layerGraph(deepnet),options);              
    

% For fine tuning, I would update the learning rate to 0.0005 or something similar. Probably leave the other variable the same. 

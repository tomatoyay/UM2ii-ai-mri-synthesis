%% Load your deepnet model
% Change your model between AX (for axial), Sag (for Sagittal), COR (for
% coronal)
load ('deepnet_unet_noNorm_98Pats_batch30_learn_05_SAG.mat');

%% Load directory of images
cd 'directory' %replace with folder of images
myFiles = dir('**/*.dcm');

%% Load list of studies
studies = xlsread('...file/test_study_list.xlsx');

%parse through files
for k = 1:height(studies)
    study = studies(k);
    %new dicomuid for new image series to match each study
    ySeriesInstanceUID = newuid;
    
    img_list = find(contains(myFiles,study) && contains(myFiles,'coronal_nfs'));
    for j = 1:height(img_list)
        path = img_list(j);
        files = split(path,"/");
        study_idx = len(files)-3;
        seq_idx = len(files)-2;
        img_idx = len(files)-1;
        study = files.study_idx;
        old_sequence = files.seq_idx;
        img = files.img_idx;
        new_sequence = 'coronal_synthfs'; %change this to sagittal or coronal when using

        % Use dicomread to read in the image and convert to square using padding
        PD_Img1 = dicomread(path);
        info = dicominfo(path,UseDictionaryVR = true);
        PD_Img = imresize(ConvertImgToSquare(PD_Img1),[256 256]);

        % Make your prediction
        testY = predict(deepnet,PD_Img);
        % Sharpen the resultant image to improve diagnostic quality
        testY = imsharpen(testY,'Radius',2.5,'Amount',1.5);
        testY = normalizeImage(testY);

        % Change new DICOM image information
        info.SeriesDescription = strcat(desc,' FS SYNTHETIC');
        info.ProtocolName = 'COR FS ORIG JHU MODEL'; %change to correct orientation
        info.SeriesNumber = 0;
        info.NumberOfPhaseEncodingSteps = 256;
        fprintf('%s\n%s\n', info.SeriesInstanceUID,ySeriesInstanceUID);
        info.SeriesInstanceUID = ySeriesInstanceUID;

        %Generate testY and save image
        new_fname = strcat(files[0]...,'/',baseFileName);
        dicomwrite(uint16(testY), new_fname, info)
        fprintf('%s\n\n', new_fname);
    end
end


function imgTemp = ConvertImgToSquare(img)

[m,n] = size(img);
imgTemp = img;
if m<n
    padNum = (n-m)/2;
    imgTemp = zeros(n,n);
    imgTemp(padNum:padNum+m-1,:) = img;
elseif m > n
    padNum = (m-n)/2;
    imgTemp = zeros(m,m);
    imgTemp(:,padNum:padNum+n-1) = img;
end